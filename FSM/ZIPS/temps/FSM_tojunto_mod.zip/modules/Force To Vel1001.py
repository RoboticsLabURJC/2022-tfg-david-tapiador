import math


def main(inputs, outputs, parameters, synchronise):


    max_v = 2
    min_v = 0.5
    max_w = 3

    try:
        while 1:     
            rep = inputs.read_array("RepForce")
            attr = inputs.read_array("AttrForce")
            if rep is not None and attr is not None:

                final_v = 1.4*rep[0] + 0.4*attr[0]
                final_w = 1.4*rep[1] + 0.4*attr[1]

                if(final_v > max_v):
                    final_v = max_v
                elif(final_v < min_v):
                    final_v = min_v

                if(final_w > max_w):
                    final_w = max_w
                elif(final_w < -max_w):
                    final_w = -max_w

                outputs.share_array("Vels", [final_v,0,0,0,0,final_w])



            synchronise()
    except Exception as e:
        print('Error:', e)
        pass
    finally:
        print("Exiting")
        synchronise()