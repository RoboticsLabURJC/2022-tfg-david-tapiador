import math



def test_max(x, y):
    ret_x = x
    ret_y = y
    angulo = 0
    max = 2
    if(x > max or y > max or x < -max or y < -max):
        if(x == 0):
            if(y >0):
                angulo = 0
            elif(y > 0):
                angulo = 180
        else:
            angulo = math.atan(y/x)
        ret_x = max*math.cos(angulo)*(x/abs(x))
        ret_y = max*math.sin(angulo)
    return ret_x, ret_y






def main(inputs, outputs, parameters, synchronise):


    max_v = 2
    min_v = 0.5
    max_w = 3

    alpha_V = 0.4
    beta_V = 1.4
    alpha_W = 1
    beta_W = 0.4

    try:
        while 1:
            rep = inputs.read_array("RepForce")
            attr = inputs.read_array("AttrForce")
            if rep is not None and attr is not None:

                attr_x, attr_y = test_max(attr[0],attr[1])
                rep_x, rep_y = test_max(rep[0],rep[1])


                final_v = alpha_V*attr_x + beta_V*rep_x
                final_w = alpha_W*attr_y - beta_W*rep_y

                if(final_v > max_v):
                    final_v = max_v
                elif(final_v < min_v):
                    final_v = min_v

                if(final_w > max_w):
                    final_w = max_w
                elif(final_w < -max_w):
                    final_w = -max_w

                print("ATTR -> " + str([round(attr_x,2), round(attr_y,2)])
                      + "\n -- REEP -> " + str([round(rep_x,2), round(rep_y,2)])
                      + "\n -- FINAL -> " + str([round(final_v,2), round(final_w,2)]))

                outputs.share_array("Vels", [final_v,0,0,0,0,final_w])



            synchronise()
    except Exception as e:
        print('Error:', e)
        pass
    finally:
        print("Exiting")
        synchronise()