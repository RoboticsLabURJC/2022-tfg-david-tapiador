def main(inputs, outputs, parameters, synchronise):
    pass