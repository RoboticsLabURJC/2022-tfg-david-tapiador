import numpy as np
import math
from time import sleep

def main(inputs, outputs, parameters, synchronise):

    kp = parameters.read_number("Kp")
    ki = parameters.read_number("Ki")
    kd = parameters.read_number("Kd")

    previousError, I = 0, 0
    enable = inputs.read_number('Enable')
    results = inputs.read_array("Inp")
    while(1):
        enable = inputs.read_number('Enable')
        results = inputs.read_array("Inp")
        if(enable):
            try:
                if(results.any()):
                    error = float(results[0]+results[2]/2)
                    sleep(0.01)

                    P = error
                    I = I + error
                    D = error - previousError
                    PIDvalue = (kp*P) + (ki*I) + (kd*D)
                    previousError = error

                    linear_velocity = 5.0
                    angular_velocity = -PIDvalue

                    data = [linear_velocity, angular_velocity]
                    outputs.share_array("Out", data)
                synchronise()
            except e:
                synchronise()
                continue