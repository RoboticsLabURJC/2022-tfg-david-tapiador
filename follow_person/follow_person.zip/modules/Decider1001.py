def main(inputs, outputs, parameters, synchronise):
    auto_enable = True
    try:
        enable = inputs.read_number("Enable")
    except Exception:
        auto_enable = True
    
    while(True):
        results = inputs.read_array("Results")
        try:
            if(results.any()):
                break
        except Exception:
            continue
    print("EMPEZAMOS")
    while(auto_enable or inputs.read_number('Enable')):
        results = inputs.read_array("Results")

        to_enable = 1
        not_to_enable = 0
        
        if(results[0] != -1):
            outputs.share_number("Rotation", not_to_enable)
            outputs.share_number("Follow", to_enable)
        else:
            outputs.share_number("Rotation", to_enable)
            outputs.share_number("Follow", not_to_enable)

