def main(inputs, outputs, parameters, synchronise):
    auto_enable = True
    try:
        enable = inputs.read_number("Enable")
    except Exception:
        auto_enable = True
    
    while(True):
        results = inputs.read_array("Results")
        try:
            if(results.any()):
                break
        except Exception:
            continue

    not_to_enable = 0
    to_enable = 1
    lowpass_filter = 2
    counter = 0

    print("EMPEZAMOS")
    while(auto_enable or inputs.read_number('Enable')):
        results = inputs.read_array("Results")

        
        if(results[0] != -1):
            counter = 0
            print("FOLL")
            outputs.share_number("Rotation", not_to_enable)
            outputs.share_number("Follow", to_enable)
        else if(counter < 10):
            counter += 1
            print("LOWP")
            outputs.share_number("Rotation", not_to_enable)
            outputs.share_number("Follow", lowpass_filter)
            cpu
        else:
            print("ROTA")
            outputs.share_number("Rotation", to_enable)
            outputs.share_number("Follow", not_to_enable)

